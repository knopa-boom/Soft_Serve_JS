1. Выбрать первое устройство
   Лампа
2. Чертеж первого устройства
   класс Lamp
      состояние
         _name : String
         _state : Boolean
         _brightness : Number (0 - 10)
      поведение
         getName() : String
         getState() : Boolean
         on() : void
         off() : void
         getBrightness() : Number
         increseBrightness() : void
         decreaseBrightness() : void
         _isNumber(Number) : Boolean
3. Набор кода для первого устройства (прототипное ООП)
4. Выбрать второе устройство
5. Чертеж второго устройства
6. Набор кода для второго устройства (прототипное ООП)
7. Общий код двух устройств выносим в класс родитель (наследнование)
8. Чертеж класса Дом
   класс SmartHouse
      состояние
         _name: String
         _devices: [Object]
      поведение
         getName(): String
         addDevice(device): void
         getDevices(): [Object]
         getDeviceByName(name): Object
         deleteDeviceByName(name): void
         offAllDevice(): void
9. Набор кода для класса Дом

Пример работы:
var sh = new SmartHouse("Name1");
sh.addDevice(new Lamp("Lamp1"));
sh.addDevice(new Lamp("Lamp2"));
console.log(sh.getDevices());
console.log(sh.getDeviceByName("Lamp2"));
sh.getDeviceByName("Lamp2").on();
sh.offAllDevice();