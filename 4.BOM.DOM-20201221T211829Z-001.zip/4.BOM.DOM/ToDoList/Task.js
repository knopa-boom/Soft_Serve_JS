"use strict";

class Task {
   constructor(name, deadline = null) {
      this._id = Task.id++;
      this._name = name;
      this._deadline = deadline;
      this._isCompleate = false;
   }
   get id() {
      return this._id;
   }
   get name() {
      return this._name
   }
   get deadline() {
      return this._deadline
   }
   get isCompleate() {
      return this._isCompleate
   }
   compleate() {
      this._isCompleate = true;
   }
   unCompleate() {
      this._isCompleate = false;
   }
}
Task.id = 1;