"use strict";

const tdl = new ToDoList(); // создали модель

const mp = document.getElementById("root"); // достали с текущего DOM точку монтирование

const tdv = new ToDoView(tdl, mp); // создали объект рисовалки
tdv.render();