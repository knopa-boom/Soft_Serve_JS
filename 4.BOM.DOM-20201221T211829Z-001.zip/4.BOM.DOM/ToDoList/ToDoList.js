"use strict";

class ToDoList {
   constructor() {
      this._tasks = [];
   }
   get tasks() {
      return this._tasks;
   }
   addTask(task) {
      this._tasks.push(task);
   }
   getTaskByName(name) {
      for (let i = 0; i < this._tasks.length; i++) {
         if (this._tasks[i].name === name) {
            return this._tasks[i];
         }
      }
      return null;
   }
   clear() {
      this._tasks = [];
   }
}