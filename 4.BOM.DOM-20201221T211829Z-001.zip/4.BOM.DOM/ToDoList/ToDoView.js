"use strict";

class ToDoView {
   constructor(model, mountPoint) {
      this._model = model; // Что рисуем?
      this._mountPoint = mountPoint; // Куда рисуем?
      
      this._nameInput = null;
      this._deadlineInput = null;
      this._toDoList = null;
   }
   _addButtonClickHandler() { // обработка клика на кнопку +
      return () => {
         // забираем с графики нужные данные
         const nameInputValue = this._nameInput.value;
         const deadlineInputValue = this._deadlineInput.value;
         // работает с Model
         const newTask = new Task(nameInputValue, deadlineInputValue);
         this._model.addTask(newTask);
         // работает с View
         const taskLi = document.createElement("li");
         taskLi.innerText = `${newTask.name} - ${newTask.deadline}`;
         taskLi.addEventListener("click", this._taskLiClickHandler);
         this._toDoList.appendChild(taskLi);
      }
   }
   _clearButtonClickHandler() { // обработка клика на кнопку "C"
      return () => {
         // работает с Model
         this._model.clear();
         // работает с View
         this._toDoList.innerText = "";
      };
   }
   _taskLiClickHandler() {
      this.classList.toggle("compleated");
   }
   render() {
      // создаем элемент
      this._nameInput = document.createElement("input");
      // настройка элемента
      this._nameInput.type = "text";
      this._nameInput.placeholder = "Task name";
      this._nameInput.style.height = "18px";
      this._nameInput.style.marginRight = "5px";
      // добавление на экран
      this._mountPoint.appendChild(this._nameInput);
      
      this._deadlineInput = document.createElement("input");
      this._deadlineInput.type = "datetime-local";
      this._deadlineInput.style.marginRight = "5px";
      this._mountPoint.appendChild(this._deadlineInput);
      
      const addButton = document.createElement("button");
      addButton.type = "button";
      addButton.innerText = "+";
      addButton.style.height = "24px";
      addButton.style.color = "green";
      addButton.addEventListener("click", this._addButtonClickHandler());
      this._mountPoint.appendChild(addButton);
      
      this._toDoList = document.createElement("ol");
      this._mountPoint.appendChild(this._toDoList);
      
      const clearButton = document.createElement("button");
      clearButton.type = "button";
      clearButton.innerText = "C";
      clearButton.style.height = "24px";
      clearButton.style.color = "red";
      clearButton.addEventListener("click", this._clearButtonClickHandler());
      this._mountPoint.appendChild(clearButton);
   }
}